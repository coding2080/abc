chrome_driver = '/Users/yutaehyeong/Desktop/chromedriver'
# chrome_driver = 'C:\devtool\driver\crawling\chromedriver'

server_no = 77011
