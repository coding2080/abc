host = '121.128.242.147'
user = 'npage'
password = 'npage12!@'
db = 'manhottan'
