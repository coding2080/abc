host = '192.168.0.43'
user = 'npage'
password = 'npage12!@'
db = 'manhottan'