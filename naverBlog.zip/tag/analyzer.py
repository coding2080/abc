from Tag import TagGenerator

if __name__ == "__main__":
    print("tag analyze start!")


    # # 태그 생성
    # tag_generator = TagGenerator(category1, category2, title)
    # tags = tag_generator.gen()
    #
    # if len(tags) < 2:
    #     continue
    #
    # for l1 in tags['level1_nouns_list']:
    #     for l2 in tags['level2_nouns_list']:
    #         tag_data_list.append({'l1': l1, 'l2': l2})
    #
    # if len(tags) == 3:
    #     for tag in tag_data_list:
    #         for l3 in tags['level3_nouns_list']:
    #             tag['l3'] = l3
    #
    # for tag_data in tag_data_list:
    #     tag_seq = self.tag_conn.select_tag(tag_data)
    #     if not tag_seq:
    #         tag_seq = self.tag_conn.insert_tag(tag_data)
    #     else:
    #         tag_seq = tag_seq[0]['tag_seq']
    #
    #     person_tag = self.person_conn.select_person_tag({'person_seq': person_seq, 'tag_seq': tag_seq})
    #     if not person_tag:
    #         self.person_conn.insert_person_tag({'person_seq': person_seq, 'tag_seq': tag_seq})
    #     else:
    #         frequency = person_tag[0]['frequency']
    #         self.person_conn.update_person_tag(
    #             {'person_seq': person_seq, 'tag_seq': tag_seq, 'frequency': (frequency + 1)}
    #         )
    #
    #     contents_tag = self.contents_conn.select_contents_tag(
    #         {'content_seq': content_seq, 'tag_seq': tag_seq})
    #     if not contents_tag:
    #         self.contents_conn.insert_contents_tag({'content_seq': content_seq, 'tag_seq': tag_seq})
    #     else:
    #         frequency = contents_tag[0]['frequency']
    #         self.contents_conn.update_contents_tag(
    #             {'content_seq': content_seq, 'tag_seq': tag_seq, 'frequency': (frequency + 1)}
    #         )
