import pymysql

import db_connection_profile


class TestConn:
    def __init__(self):
        self.conn = pymysql.connect(host=db_connection_profile.host,
                                    user=db_connection_profile.user,
                                    password=db_connection_profile.password,
                                    db=db_connection_profile.db,
                                    charset='utf8')
        self.cur = self.conn.cursor()

    def select_content_seq_1000(self, depth, offset):
        try:
            print('select_category_100')
            sql = 'SELECT blog_info_seq ' \
                  'FROM spyder_naver_blog_info_back ' \
                  'WHERE depth = %s ' \
                  'LIMIT 1000 OFFSET %s'
            self.cur.execute(sql, [depth, offset])
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError:
            print('database error')

        return []

    def select_content_by_parent_seq(self, seq, offset):
        try:
            print('select_category_100')
            sql = 'SELECT blog_info_seq, division_code ' \
                  'FROM spyder_naver_blog_info_back ' \
                  'WHERE parent_info_seq = %s ' \
                  'LIMIT 1000 OFFSET %s'
            self.cur.execute(sql, [seq, offset])
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError:
            print('database error')

        return []

    def select_words(self, seq):
        try:
            print('select_category_100')
            sql = 'SELECT word_seq ' \
                  'FROM spyder_naver_blog_extract_pos_back ' \
                  'WHERE blog_info_seq = %s AND analyzer_code = %s AND morpheme_code = %s'
            self.cur.execute(sql, [seq, 'Kkma', 'NNG'])
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError:
            print('database error')

        return []

    def select_relation(self, parent_seq, child_seq):
        try:
            print('select_relation')
            sql = 'SELECT score ' \
                  'FROM test ' \
                  'WHERE parent_seq = %s AND child_seq = %s '
            self.cur.execute(sql, [parent_seq, child_seq])
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError:
            print('database error')

    def insert_relation(self, data):
        try:
            print('insert_relation')
            sql = 'INSERT INTO ' \
                  'test(parent_seq, child_seq, score) ' \
                  'VALUES (%(parent_seq)s, %(child_seq)s, %(score)s)'
            self.cur.executemany(sql, data)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def update_relation_score(self, parent_seq, child_seq, score):
        try:
            print('update_relation_score')
            sql = 'UPDATE test ' \
                  'SET score = %s ' \
                  'WHERE parent_seq = %s AND child_seq = %s'
            self.cur.execute(sql, [score, parent_seq, child_seq])
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))
