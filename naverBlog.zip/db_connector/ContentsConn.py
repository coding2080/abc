from datetime import datetime
import pymysql
import db_connection_profile
import path
import logging
import traceback


class ContentsConn:

    def __init__(self):
        self.conn = pymysql.connect(host=db_connection_profile.host,
                                    user=db_connection_profile.user,
                                    password=db_connection_profile.password,
                                    db=db_connection_profile.db,
                                    charset='utf8mb4',
                                    connect_timeout=11)
        self.cur = self.conn.cursor(pymysql.cursors.DictCursor)

    def close(self):
        self.cur.close()
        self.conn.close()

    def insert_content(self, data):
        data['crt_by'] = path.machine_index
        data['crt_dt'] = datetime.now()
        try:
            sql = 'INSERT INTO contents(person_seq, url, category1, category2, title, descript, img_url, crt_by, crt_dt) ' \
                  'VALUES (%(person_seq)s, %(url)s, %(category1)s, %(category2)s, %(title)s, %(descript)s, %(img_url)s, %(crt_by)s, %(crt_dt)s)'
            self.cur.execute(sql, data)
            seq = self.cur.lastrowid
            self.conn.commit()
            return seq
        except pymysql.err.MySQLError as e:
            logging.warning('mysql error: ' + traceback.format_exc())
        except pymysql.err.DataError as e:
            logging.warning('database error: ' + traceback.format_exc())

    def select_contents_tag(self, data):
        try:
            sql = 'SELECT * ' \
                  'FROM contents_tag ' \
                  'WHERE content_seq = %(content_seq)s ' \
                  'AND tag_seq = %(tag_seq)s'
            self.cur.execute(sql, data)
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            logging.warning('mysql error: ' + traceback.format_exc())
        except pymysql.err.DataError as e:
            logging.warning('database error: ' + traceback.format_exc())

    def insert_contents_tag(self, data):
        data['crt_by'] = path.machine_index
        try:
            sql = 'INSERT INTO contents_tag(content_seq, tag_seq, crt_by) ' \
                  'VALUES (%(content_seq)s, %(tag_seq)s, %(crt_by)s)'
            self.cur.execute(sql, data)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            logging.warning('mysql error: ' + traceback.format_exc())
        except pymysql.err.DataError as e:
            logging.warning('database error: ' + traceback.format_exc())

    def update_contents_tag(self, data):
        data['mod_by'] = path.machine_index
        try:
            sql = 'UPDATE contents_tag ' \
                  'SET frequency = %(frequency)s, mod_by = %(mod_by)s ' \
                  'WHERE content_seq = %(content_seq)s and tag_seq = %(tag_seq)s'
            self.cur.execute(sql, data)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            logging.warning('mysql error: ' + traceback.format_exc())
        except pymysql.err.DataError as e:
            logging.warning('database error: ' + traceback.format_exc())

    def insert_contents(self, data):
        try:
            sql = 'INSERT INTO contents(person_seq, url, category1, category2, title, descript, img_url, crt_by, crt_dt) ' \
                  'VALUES (%(person_seq)s, %(url)s, %(category1)s, %(category2)s, %(title)s, %(descript)s, %(img_url)s, %(crt_by)s, %(crt_dt)s)'
            self.cur.executemany(sql, data)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            logging.warning('mysql error: ' + traceback.format_exc())
        except pymysql.err.DataError as e:
            logging.warning('database error: ' + traceback.format_exc())

    def insert_contents_no_meta(self, data):
        try:
            sql = 'INSERT INTO contents(person_seq, url, category1, category2, title, crt_by, crt_dt) ' \
                  'VALUES (%(person_seq)s, %(url)s, %(category1)s, %(category2)s, %(title)s, %(crt_by)s, %(crt_dt)s)'
            self.cur.executemany(sql, data)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            logging.warning('mysql error: ' + traceback.format_exc())
        except pymysql.err.DataError as e:
            logging.warning('database error: ' + traceback.format_exc())
