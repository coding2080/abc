from datetime import datetime

import pymysql

import db_connection_profile
import logging
import traceback

class PlatformConn:

    def __init__(self):
        self.conn = pymysql.connect(host=db_connection_profile.host,
                                    user=db_connection_profile.user,
                                    password=db_connection_profile.password,
                                    db=db_connection_profile.db,
                                    charset='utf8mb4',
                                    connect_timeout=11)
        self.cur = self.conn.cursor(pymysql.cursors.DictCursor)

    def close(self):
        self.cur.close()
        self.conn.close()

    def select_platform(self, domain):
        try:
            print('select_platform')
            sql = 'SELECT * ' \
                  'FROM platform ' \
                  'WHERE domain = %s'
            self.cur.execute(sql, domain)
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error:' + str(e))


