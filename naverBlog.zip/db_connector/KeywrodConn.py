import pymysql

import db_connection_profile
import logging
import traceback


class KeywordConn:
    def __init__(self):
        self.conn = pymysql.connect(host=db_connection_profile.host,
                                    user=db_connection_profile.user,
                                    password=db_connection_profile.password,
                                    db=db_connection_profile.db,
                                    charset='utf8mb4')
        self.cur = self.conn.cursor()

    def select_keywords(self):
        try:
            print('select_url_cnt')
            sql = 'SELECT keyword ' \
                  'FROM keyword '
            self.cur.execute(sql)
            keywords = self.cur.fetchall()
            self.conn.commit()
            return keywords
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError:
            print('database error')
