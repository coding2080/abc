from datetime import datetime

import pymysql

import db_connection_profile
import path
import logging
import traceback


class MachineKeywordConn:

    def __init__(self):
        self.conn = pymysql.connect(host=db_connection_profile.host,
                                    user=db_connection_profile.user,
                                    password=db_connection_profile.password,
                                    db=db_connection_profile.db,
                                    charset='utf8mb4',
                                    connect_timeout=11)
        # self.cur = self.conn.cursor(pymysql.cursors.DictCursor)
        self.cur = self.conn.cursor()

    def close(self):
        self.cur.close()
        self.conn.close()

    def select_keywords(self, machine_index):
        try:
            sql = 'SELECT keyword ' \
                  'FROM machine_keyword ' \
                  'WHERE machine_index = %s '
            self.cur.execute(sql, machine_index)
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            logging.warning('mysql error: ' + traceback.format_exc())
        except pymysql.err.DataError as e:
            logging.warning('database error:' + traceback.format_exc())
