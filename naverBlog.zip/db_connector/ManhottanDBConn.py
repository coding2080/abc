from datetime import datetime

import pymysql

import db_connection_profile


class ManhottanDBConn:

    def __init__(self):
        self.conn = pymysql.connect(host=db_connection_profile.host,
                                    user=db_connection_profile.user,
                                    password=db_connection_profile.password,
                                    db=db_connection_profile.db,
                                    charset='utf8',
                                    connect_timeout=11)
        self.cur = self.conn.cursor()

    def close(self):
        self.cur.close()
        self.conn.close()

    def insert_person(self, data):
        try:
            print('insert_person')
            sql = 'INSERT INTO person(url, blogger, blog_name, search_keyword) ' \
                  'VALUES (%(url)s, %(blogger)s, %(blog_name)s, %(keyword)s)'
            self.cur.execute(sql, data)
            self.conn.commit()
        except Exception as e:
            data = {'error_type': 'query', 'url': data['url'], 'error_msg': str(e), 'crt_dt': datetime.now()}
            self.query_error(data)

    def crawling_error(self, data):
        try:
            print('crawling_error')
            sql = 'INSERT INTO crawling_error(error_type, url, error_msg, crt_dt) ' \
                  'VALUES (%(error_type)s, %(url)s, %(error_msg)s, %(crt_dt)s)'
            self.cur.execute(sql, data)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError:
            print('database error')
        except Exception as e:
            print(e)

    def query_error(self, data):
        try:
            print('query_error')
            sql = 'INSERT INTO crawling_error(error_type, url, error_msg, crt_dt) ' \
                  'VALUES (%(error_type)s, %(url)s, %(error_msg)s, %(crt_dt)s)'
            self.cur.execute(sql, data)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError:
            print('database error')
        except Exception as e:
            print(e)

    # def select_url_cnt(self, keyword):
    #     try:
    #         print('select_url_cnt')
    #         sql = 'SELECT COUNT(*) ' \
    #               'FROM spyder_naver_blog_base ' \
    #               'WHERE search_keyword=%s'
    #         self.cur.execute(sql, keyword)
    #         cnt = self.cur.fetchall()
    #         self.conn.commit()
    #         return cnt[0][0]
    #     except pymysql.err.MySQLError as e:
    #         print('mysql error: ' + str(e))
    #     except pymysql.err.DataError:
    #         print('database error')
    #
    #     return 0

    def select_url_100(self, keyword, last_seq):
        try:
            print('select_url_100')
            sql = 'SELECT blog_id_seq, url ' \
                  'FROM spyder_naver_blog_base ' \
                  'WHERE search_keyword=%s AND blog_id_seq > %s ' \
                  'LIMIT 100'
            self.cur.execute(sql, [keyword, last_seq])
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError:
            print('database error')

        return []

    def select_url_by_keyword(self, keyword):
        try:
            print('select_url_by_keyword')
            sql = 'SELECT blog_id_seq, url ' \
                  'FROM spyder_naver_blog_base ' \
                  'WHERE search_keyword=%s'
            self.cur.execute(sql, keyword)
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError:
            print('database error')

        return []

    def insert_category(self, data):
        try:
            print('insert_category')
            sql = 'INSERT INTO ' \
                  'spyder_naver_blog_info(blog_id_seq, post_seq, depth, content, division_code,' \
                  ' parent_info_seq, post_write_date, crt_dt) ' \
                  'VALUES (%(blog_id_seq)s, %(post_seq)s, %(depth)s, %(content)s, %(division_code)s,' \
                  ' %(parent_info_seq)s, %(post_write_date)s, %(crt_dt)s)'
            self.cur.execute(sql, data)
            seq = self.cur.lastrowid
            self.conn.commit()
            return seq
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

        return None

    def insert_category_list(self, data):
        try:
            print('insert_category')
            sql = 'INSERT INTO ' \
                  'spyder_naver_blog_info(blog_id_seq, post_seq, depth, content, division_code,' \
                  ' parent_info_seq, post_write_date, crt_dt) ' \
                  'VALUES (%(blog_id_seq)s, %(post_seq)s, %(depth)s, %(content)s, %(division_code)s,' \
                  ' %(parent_info_seq)s, %(post_write_date)s, %(crt_dt)s)'
            self.cur.executemany(sql, data)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def update_person(self, person):
        try:
            print('update_person')
            sql = 'UPDATE person ' \
                  'SET intro = %(intro)s, profile_url = %(profile_url)s, ' \
                  'recent_post_dt = %(recent_post_dt)s ' \
                  'WHERE url = %(url)s'
            self.cur.execute(sql, person)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def select_last_url_seq(self, keyword):
        try:
            print('select_last_url_seq')
            sql = 'select max(info.blog_id_seq) ' \
                  'from spyder_naver_blog_base as base ' \
                  'join spyder_naver_blog_info as info ' \
                  'where base.blog_id_seq=info.blog_id_seq and base.search_keyword=%s'
            self.cur.execute(sql, keyword)
            last_seq = self.cur.fetchall()
            self.conn.commit()
            return last_seq[0][0]
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def select_info_seq(self, data):
        try:
            print('select_info_seq')
            sql = 'SELECT blog_info_seq ' \
                  'FROM spyder_naver_blog_info ' \
                  'WHERE blog_id_seq = %s and category_seq = %s and depth = %s'
            self.cur.execute(sql, data)
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError:
            print('database error')

    def insert_info_category_seq(self, data):
        try:
            print('insert_category')
            sql = 'INSERT INTO ' \
                  'word_master(word) ' \
                  'VALUES (%s)'
            self.cur.execute(sql, data)
            seq = self.cur.lastrowid
            self.conn.commit()
            return seq
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

        return -1
