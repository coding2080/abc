from datetime import datetime

import pymysql

import db_connection_profile
import path
import logging
import traceback


class TagConn:

    def __init__(self):
        self.conn = pymysql.connect(host=db_connection_profile.host,
                                    user=db_connection_profile.user,
                                    password=db_connection_profile.password,
                                    db=db_connection_profile.db,
                                    charset='utf8mb4',
                                    connect_timeout=11)
        self.cur = self.conn.cursor(pymysql.cursors.DictCursor)

    def close(self):
        self.cur.close()
        self.conn.close()

    def select_tag(self, tag):
        try:
            sql = 'SELECT tag_seq ' \
                  'FROM tag'
            if len(tag) == 2:
                sql += ' WHERE level_1 = %(l1)s and level_2 = %(l2)s and level_3 is null'
            elif len(tag) == 3:
                sql += ' WHERE level_1 = %(l1)s and level_2 = %(l2)s and level_3 = %(l3)s'

            self.cur.execute(sql, tag)
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def insert_tag(self, data):
        data['crt_by'] = path.machine_index
        try:
            sql = 'INSERT INTO tag(level_1, level_2, level_3, crt_by)'

            if len(data) == 2:
                sql += ' VALUES (%(l1)s, %(l2)s, null, %(crt_by)s)'
            elif len(data) == 3:
                sql += ' VALUES (%(l1)s, %(l2)s, %(l3)s, %(crt_by)s)'

            self.cur.execute(sql, data)
            seq = self.cur.lastrowid
            self.conn.commit()
            return seq
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))
