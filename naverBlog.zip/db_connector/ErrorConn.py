import pymysql
import db_connection_profile
import path

class ErrorConn:

    def __init__(self):
        self.conn = pymysql.connect(host=db_connection_profile.host,
                                    user=db_connection_profile.user,
                                    password=db_connection_profile.password,
                                    db=db_connection_profile.db,
                                    charset='utf8')
        self.cur = self.conn.cursor()

    def select_crawling_error_cnt(self):
        try:
            print('select_crawling_error_cnt')
            sql = 'SELECT COUNT(*) ' \
                  'FROM crawling_error '
            self.cur.execute(sql)
            cnt = self.cur.fetchall()
            self.conn.commit()
            return cnt[0][0]
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError:
            print('database error')

        return 0
