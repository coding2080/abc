import datetime

import pymysql

import db_connection_profile


class WordConn:

    def __init__(self):
        self.conn = pymysql.connect(host=db_connection_profile.host,
                                    user=db_connection_profile.user,
                                    password=db_connection_profile.password,
                                    db=db_connection_profile.db,
                                    charset='utf8')
        self.cur = self.conn.cursor()

    def close(self):
        self.cur.close()
        self.conn.close()

    # def select_category_cnt(self):
    #     try:
    #         print('select_category_cnt')
    #         sql = 'SELECT COUNT(*) ' \
    #               'FROM spyder_naver_blog_info '
    #         self.cur.execute(sql)
    #         cnt = self.cur.fetchall()
    #         self.conn.commit()
    #         return cnt[0][0]
    #     except pymysql.err.MySQLError as e:
    #         print('mysql error: ' + str(e))
    #     except pymysql.err.DataError:
    #         print('database error')
    #
    #     return 0

    def select_category_1000(self, last_seq):
        try:
            print('select_category_100')
            sql = 'SELECT blog_info_seq, content ' \
                  'FROM spyder_naver_blog_info ' \
                  'WHERE blog_info_seq > %s ' \
                  'LIMIT 1000'
            self.cur.execute(sql, last_seq)
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError:
            print('database error')

        return []

    def insert(self, data):
        try:
            sql = 'INSERT INTO ' \
                  'test(search_keyword, depth1, depth2, depth3) ' \
                  'VALUES (%(search_keyword)s, %(depth1)s, %(depth2)s, %(depth3)s)'
            self.cur.execute(sql, data)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def select_word(self, word):
        try:
            print('select_word')
            sql = 'SELECT word_seq, word ' \
                  'FROM word_master ' \
                  'WHERE word = %s'
            self.cur.execute(sql, word)
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError:
            print('database error')

    def insert_word(self, word):
        try:
            print('insert_word')
            sql = 'INSERT INTO ' \
                  'word_master(word, crt_dt) ' \
                  'VALUES (LOWER(%s), %s)'
            self.cur.execute(sql, [word, datetime.datetime.now()])
            seq = self.cur.lastrowid
            self.conn.commit()
            return seq
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

        return -1

    def insert_pos(self, data):
        try:
            print('insert_pos')
            sql = 'INSERT INTO ' \
                  'spyder_naver_blog_extract_pos(blog_info_seq, word_seq, morpheme_code, analyzer_code) ' \
                  'VALUES (%(blog_info_seq)s, %(word_seq)s, %(morpheme_code)s, %(analyzer_code)s)'
            self.cur.execute(sql, data)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def insert_nng(self, data):
        try:
            print('insert_nng')
            sql = 'INSERT INTO ' \
                  'spyder_naver_blog_nng(blog_info_seq, word_seq, analyzer_code) ' \
                  'VALUES (%(blog_info_seq)s, %(word_seq)s, %(analyzer_code)s)'
            self.cur.execute(sql, data)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def insert_nouns_master(self, nouns):
        try:
            print('insert_nouns_master')
            sql = 'INSERT INTO ' \
                  'nouns_master(nouns) ' \
                  'VALUES (%s)'
            self.cur.execute(sql, nouns)
            seq = self.cur.lastrowid
            self.conn.commit()
            return seq
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

        return -1

    def insert_nouns(self, data):
        try:
            print('insert_nouns')
            sql = 'INSERT INTO ' \
                  'spyder_naver_blog_extract_nouns(blog_info_seq, nouns_master_seq, analyzer_code) ' \
                  'VALUES (%(blog_info_seq)s, %(nouns_master_seq)s, %(analyzer_code)s)'
            self.cur.execute(sql, data)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def select_last_info_seq(self):
        try:
            print('select_last_url_seq')
            sql = 'select max(blog_info_seq), count(*) ' \
                  'from spyder_naver_blog_extract_pos '
            self.cur.execute(sql)
            last_seq = self.cur.fetchall()
            self.conn.commit()
            return last_seq[0]
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def insert_nng_compound(self, data):
        try:
            print('insert_nng_compound')
            sql = 'INSERT INTO ' \
                  'nng_compound(blog_info_seq, ref_seq, division, analyzer_code) ' \
                  'VALUES (%(blog_info_seq)s, %(ref_seq)s, %(division)s, %(analyzer_code)s)'
            self.cur.execute(sql, data)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def select_nouns(self, compound_word):
        try:
            print('select_nouns')
            sql = 'select nouns_master_seq, nouns ' \
                  'from nouns_master ' \
                  'where nouns = %s'
            self.cur.execute(sql, compound_word)
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def insert_compound(self, data):
        try:
            print('insert_compound')
            sql = 'INSERT INTO ' \
                  'spyder_naver_blog_compound(blog_info_seq, compound_master_seq, analyzer_code) ' \
                  'VALUES (%(blog_info_seq)s, %(compound_master_seq)s, %(analyzer_code)s)'
            self.cur.execute(sql, data)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def select_compound_word(self, compound_word):
        try:
            print('select_compound_word')
            sql = 'SELECT compound_master_seq, compound_word ' \
                  'FROM compound_master ' \
                  'WHERE compound_word = %s'
            self.cur.execute(sql, compound_word)
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError:
            print('database error')

    def insert_compound_master(self, compound_word):
        try:
            print('insert_compound_master')
            sql = 'INSERT INTO ' \
                  'compound_master(compound_word, crt_dt) ' \
                  'VALUES (LOWER(%s), %s)'
            self.cur.execute(sql, compound_word, datetime.datetime.now())
            seq = self.cur.lastrowid
            self.conn.commit()
            return seq
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

        return -1

    def select_top_200_blog_by_keyword(self, keyword, min_date):
        try:
            print('select_last_url_seq')
            sql = 'select blog_id_seq ' \
                  'from spyder_naver_blog_base ' \
                  'where search_keyword = %s ' \
                  'and post_cnt < 1000 ' \
                  'and recent_post_date > %s ' \
                  'limit 200'
            self.cur.execute(sql, [keyword, min_date])
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def select_blog_by_keyword(self, keyword):
        try:
            print('select_last_url_seq')
            sql = 'select distinct blog_id_seq ' \
                  'from spyder_naver_blog_info ' \
                  'where blog_id_seq in (' \
                  'select blog_id_seq ' \
                  'from spyder_naver_blog_base ' \
                  'where search_keyword = %s' \
                  ')'
            self.cur.execute(sql, keyword)
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def select_blog_info_by_id(self, blog_id):
        try:
            print('select_last_url_seq')
            sql = 'select blog_info_seq, content ' \
                  'from spyder_naver_blog_info ' \
                  'where blog_id_seq = %s '
            self.cur.execute(sql, blog_id)
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def select_blog_info_by_id_and_date(self, blog_id, min_date):
        try:
            print('select_last_url_seq')
            sql = 'select blog_info_seq, content ' \
                  'from spyder_naver_blog_info ' \
                  'where blog_id_seq = %s ' \
                  'and post_write_date > %s'
            self.cur.execute(sql, [blog_id, min_date])
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def insert_pos_list(self, pos_data_list):
        try:
            print('insert_pos_list')
            sql = 'INSERT INTO ' \
                  'spyder_naver_blog_extract_pos(blog_info_seq, word_seq, morpheme_code, analyzer_code) ' \
                  'VALUES (%(blog_info_seq)s, %(word_seq)s, %(morpheme_code)s, %(analyzer_code)s)'
            self.cur.executemany(sql, pos_data_list)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def insert_nng_list(self, nng_data_list):
        try:
            print('insert_nng_list')
            sql = 'INSERT INTO ' \
                  'spyder_naver_blog_nng(blog_info_seq, word_seq, analyzer_code) ' \
                  'VALUES (%(blog_info_seq)s, %(word_seq)s, %(analyzer_code)s)'
            self.cur.executemany(sql, nng_data_list)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def insert_nng_compound_list(self, nng_compound_data_list):
        try:
            print('insert_nng_compound_list')
            sql = 'INSERT INTO ' \
                  'nng_compound(blog_info_seq, ref_seq, division, analyzer_code) ' \
                  'VALUES (%(blog_info_seq)s, %(ref_seq)s, %(division)s, %(analyzer_code)s)'
            self.cur.executemany(sql, nng_compound_data_list)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def insert_compound_list(self, compound_data_list):
        try:
            print('insert_compound_list')
            sql = 'INSERT INTO ' \
                  'spyder_naver_blog_compound(blog_info_seq, compound_master_seq, analyzer_code) ' \
                  'VALUES (%(blog_info_seq)s, %(compound_master_seq)s, %(analyzer_code)s)'
            self.cur.executemany(sql, compound_data_list)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def select_word_all(self):
        try:
            print('select_word_all')
            sql = 'select word_seq, word ' \
                  'from word_master '
            self.cur.execute(sql)
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def select_compound_all(self):
        try:
            print('select_compound_all')
            sql = 'select compound_master_seq, compound_word ' \
                  'from compound_master '
            self.cur.execute(sql)
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))