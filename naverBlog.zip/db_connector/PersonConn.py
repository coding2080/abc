from datetime import datetime

import pymysql

import db_connection_profile
import path
import logging
import traceback


class PersonConn:

    def __init__(self):
        self.conn = pymysql.connect(host=db_connection_profile.host,
                                    user=db_connection_profile.user,
                                    password=db_connection_profile.password,
                                    db=db_connection_profile.db,
                                    charset='utf8mb4',
                                    connect_timeout=11)
        self.cur = self.conn.cursor(pymysql.cursors.DictCursor)

    def close(self):
        self.cur.close()
        self.conn.close()

    def insert_person(self, insert_data, person_category_object):
        select_param_object = {'platform_seq': insert_data['platform_seq'], 'id': insert_data['blogger']}
        insert_data['crt_by'] = path.machine_index
        try:
            
            sql = 'INSERT INTO person(platform_seq, url, id, name, crt_by) ' \
                  'VALUES (%(platform_seq)s, %(url)s, %(blogger)s, %(blog_name)s, %(crt_by)s)'
            self.cur.execute(sql, insert_data)
            seq = self.cur.lastrowid
            self.conn.commit()
            person_category_object['person_seq'] = seq
            self.insert_person_category(person_category_object)
        except pymysql.err.MySQLError as e:
            # ID 중복으로 입력 불가 시
            if e.args[0] == 1062:
                person_info = self.select_one_person(select_param_object)
                person_category_object['person_seq'] = person_info['person_seq']
                self.insert_person_category(person_category_object)
            else:
                print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def update_person(self, person):
        person['mod_by'] = path.machine_index
        person['mod_dt'] = datetime.now()
        try:
            sql = 'UPDATE person ' \
                  'SET intro = %(intro)s, profile_url = %(profile_url)s, ' \
                  'recent_post_dt = %(recent_post_dt)s, mod_by = %(mod_by)s, mod_dt = %(mod_dt)s ' \
                  'WHERE person_seq = %(person_seq)s'
            self.cur.execute(sql, person)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            logging.warning('mysql error: ' + traceback.format_exc())
        except pymysql.err.DataError as e:
            logging.warning('mysql error: ' + traceback.format_exc())

    def select_one_person(self, data):
        try:
            sql = 'SELECT * ' \
                  'FROM person ' \
                  'WHERE platform_seq = %(platform_seq)s ' \
                  'AND id = %(id)s'
            self.cur.execute(sql, data)
            result = self.cur.fetchone()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            logging.warning('mysql error: ' + traceback.format_exc())
        except pymysql.err.DataError as e:
            logging.warning('mysql error: ' + traceback.format_exc())

    def select_people_1000(self, last_seq):
        try:
            print('select_people_1000')
            sql = 'SELECT * ' \
                  'FROM person ' \
                  'WHERE person_seq > %s ' \
                  'LIMIT 1000'
            self.cur.execute(sql, last_seq)
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            logging.warning('mysql error: ' + traceback.format_exc())
        except pymysql.err.DataError as e:
            logging.warning('database error: ' + traceback.format_exc())

    def select_500_people_by_keyword(self, keyword, last_seq):
        try:
            print('select_people_by_keyword, keyword :', keyword)
            sql = 'SELECT p.* ' \
                  'FROM person p ' \
                  'LEFT JOIN person_category pc on p.person_seq = pc.person_seq ' \
                  'WHERE pc.keyword = %s and p.person_seq > %s ' \
                  'LIMIT 500'
            self.cur.execute(sql, [keyword, last_seq])
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            logging.warning('mysql error: ' + traceback.format_exc())
        except pymysql.err.DataError as e:
            logging.warning('database error: ' + traceback.format_exc())

    def insert_person_category(self, person_category_data):
        person_category_data['crt_by'] = path.machine_index
        try:
            sql = 'INSERT INTO person_category(person_seq, category_seq, enter_div_cd, keyword, crt_by) ' \
                  'VALUES (%(person_seq)s, %(category_seq)s, %(enter_div_cd)s, %(keyword)s, %(crt_by)s) '
            self.cur.execute(sql, person_category_data)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            if e.args[0] != 1062:
                logging.warning('mysql error: ' + traceback.format_exc())
        except pymysql.err.DataError as e:
            logging.warning('database error: ' + traceback.format_exc())

    def select_person_tag(self, data):
        try:
            sql = 'SELECT * ' \
                  'FROM person_tag ' \
                  'WHERE person_seq = %(person_seq)s ' \
                  'AND tag_seq = %(tag_seq)s'
            self.cur.execute(sql, data)
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def insert_person_tag(self, data):
        data['crt_by'] = path.machine_index
        data['crt_dt'] = datetime.now()
        try:
            sql = 'INSERT INTO person_tag(person_seq, tag_seq, crt_by, crt_dt) ' \
                  'VALUES (%(person_seq)s, %(tag_seq)s, %(crt_by)s, %(crt_dt)s)'
            self.cur.execute(sql, data)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def update_person_tag(self, data):
        data['mod_by'] = path.machine_index
        data['mod_dt'] = datetime.now()
        try:
            sql = 'UPDATE person_tag ' \
                  'SET frequency = %(frequency)s, mod_by = %(mod_by)s, mod_dt = %(mod_dt)s ' \
                  'WHERE person_seq = %(person_seq)s and tag_seq = %(tag_seq)s'
            self.cur.execute(sql, data)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))
