import configparser as parser

# 머신설정 파일 읽기
server_config = parser.ConfigParser()
server_config.read('/Users/yutaehyeong/Desktop/python/server_config.ini')
# server_config.read('/root/config/server_config.ini')

machine_index = server_config['machine_setting']['index']
chrome_driver_path = server_config['chrome_setting']['driver_path']
tag_start_seq = server_config['tag_start_seq']['seq']
tag_end_seq = server_config['tag_end_seq']['seq']
