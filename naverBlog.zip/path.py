# chrome_driver = '/Users/yutaehyeong/Desktop/chromedriver'
chrome_driver = '/root/crawling/chromedriver'
