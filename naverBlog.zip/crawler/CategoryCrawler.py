from datetime import datetime
from time import sleep

from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

import path
from Konlpy import MorphemeAnalyzer
from Tag import TagGenerator
from db_connector.ContentsConn import ContentsConn
from db_connector.PersonConn import PersonConn
import requests
from bs4 import BeautifulSoup
from db_connector.TagConn import TagConn


class CategoryCrawler:

    def __init__(self):
        self.morpheme_analyzer = MorphemeAnalyzer()
        self.person_conn = PersonConn()
        self.tag_conn = TagConn()
        self.contents_conn = ContentsConn()
        self.last_post_dt = None
        self.driver = webdriver.Chrome(path.chrome_driver)
        self.wait_time = 7

    def close(self):
        self.driver.close()
        self.person_conn.close()
        self.tag_conn.close()
        self.contents_conn.close()

    def crawl(self, person):
        person_seq = person['person_seq']
        url = person['url']
        # url = 'https://blog.naver.com/entrustlaw'
        self.last_post_dt = person['recent_post_dt']
        if self.last_post_dt is None:
            self.last_post_dt = datetime.strptime('2001. 01. 01.', '%Y. %m. %d.')

        try:
            # 블로그 페이지를 로드한다.
            self.load_blog_page(url)

            # 블로그 최상단 메뉴 목록을 가져온다.
            blog_menus = self.scrape_blog_menu()

            # 블로그 메인 화면 진입시 블로그 메뉴가 프롤로그일 경우 카테고리가 안나온다.
            # 프롤로그가 아닌 다른 메뉴를 클릭하면 카테고리가 나온다.
            # 블로그 메뉴가 1개인 경우 따로 메뉴를 클릭할 필요는 없다. (메뉴는 블로그 마다 갯수가 다름)
            if len(blog_menus) > 1:
                self.click_element(blog_menus[1])

            # 블로그 소개글을 가져온다.
            blog_intro = self.scrape_intro_txt()
            # 블로그 소개글의 &nbsp(줄넘김 방지 공백 문자)를 그냥 공백으로 치환한다.
            blog_intro = blog_intro.replace('\xa0', ' ')

            # 프로필 이미지 url을 가져온다.
            image_url = self.scrape_image_url()

            # 카테고리가 닫혀있는 경우 클릭하여 카테고리 목록을 열어준다.
            if self.is_category_closed():
                self.open_category_list()

            # 카테고리 li 목록을 가져온다.
            lis = self.scrape_category()

            # 블로그의 총 포스트 수를 가져온다.
            total_post_cnt = self.scrape_total_post_cnt(lis[0])

            # 전체보기 카테고리를 클릭한다.
            self.click_element(lis[0])

            # 최신 포스트 작성 날짜를 가져온다.
            recent_post_dt = self.scrape_recent_post_date()

            # 최신 포스트 작성 날짜가 24시간 이내일 경우 '15시간 전'과 같이 표시되기 때문에
            # 현재 날짜로 지정한다.
            if len(recent_post_dt) > 10:
                recent_post_dt = datetime.strptime(recent_post_dt, '%Y. %m. %d.')
            else:
                recent_post_dt = datetime.now()

            if recent_post_dt <= self.last_post_dt:
                sleep(self.wait_time)
                return

            # 블로그 정보를 업데이트 한다.
            update_blog_data = {'person_seq': person_seq, 'url': url, 'intro': blog_intro, 'profile_url': image_url,
                                'post_cnt': int(total_post_cnt), 'recent_post_dt': recent_post_dt}
            self.person_conn.update_person(update_blog_data)

            posts = []

            lis_cnt = len(self.scrape_category())
            for i in range(1, lis_cnt):
                # 카테고리 목록을 가져온다.
                # driver 가 링크를 클릭했을 경우 카테고리 목록을 새롭게 가져와야 한다.
                lis = self.scrape_category()
                li = lis[i]

                # 카테고리 뎁스 1인 경우
                if self.is_depth1_category(li):

                    # 카테고리명을 가져온다.
                    level1_phrase = li.find_element(By.TAG_NAME, 'a').get_attribute('textContent')

                    result_posts = self.scrape_post(li)
                    for post in result_posts:
                        posts.append((level1_phrase,) + post)

            for category1, category2, title, desc, img, date, post_no, url in posts:
                # print('카테고리1:', category1, '// 카테고리2:', category2, '// 제목:', title, '// 내용:', desc, '// 이미지:', img,
                #       '// 날짜:', date)

                content_seq = self.contents_conn.insert_content(
                    {'person_seq': person_seq,
                     'url': url,
                     'category1': category1,
                     'category2': None if category1 == category2 else category2,
                     'title': title,
                     'descript': desc,
                     'img_url': img,
                     }
                )

                tag_data_list = []

                # 태그 생성
                tag_generator = TagGenerator(category1, category2, title)
                tags = tag_generator.gen()

                if len(tags) < 2:
                    continue

                for l1 in tags['level1_nouns_list']:
                    for l2 in tags['level2_nouns_list']:
                        tag_data_list.append({'l1': l1, 'l2': l2})

                if len(tags) == 3:
                    for tag in tag_data_list:
                        for l3 in tags['level3_nouns_list']:
                            tag['l3'] = l3

                for tag_data in tag_data_list:
                    tag_seq = self.tag_conn.select_tag(tag_data)
                    if not tag_seq:
                        tag_seq = self.tag_conn.insert_tag(tag_data)
                    else:
                        tag_seq = tag_seq[0]['tag_seq']

                    person_tag = self.person_conn.select_person_tag({'person_seq': person_seq, 'tag_seq': tag_seq})
                    if not person_tag:
                        self.person_conn.insert_person_tag({'person_seq': person_seq, 'tag_seq': tag_seq})
                    else:
                        frequency = person_tag[0]['frequency']
                        self.person_conn.update_person_tag(
                            {'person_seq': person_seq, 'tag_seq': tag_seq, 'frequency': (frequency + 1)}
                        )

                    contents_tag = self.contents_conn.select_contents_tag(
                        {'content_seq': content_seq, 'tag_seq': tag_seq})
                    if not contents_tag:
                        self.contents_conn.insert_contents_tag({'content_seq': content_seq, 'tag_seq': tag_seq})
                    else:
                        frequency = contents_tag[0]['frequency']
                        self.contents_conn.update_contents_tag(
                            {'content_seq': content_seq, 'tag_seq': tag_seq, 'frequency': (frequency + 1)}
                        )

        except Exception as e:
            tag_data = {'error_type': 'naver blog category', 'url': url, 'error_msg': str(e),
                        'crt_dt': datetime.now()}
            print('에러:', tag_data)

    def scrape_blog_menu(self):
        element = WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.ID, 'blog-menu')))
        return element.find_element(By.CLASS_NAME, 'menu1') \
            .find_elements(By.TAG_NAME, 'li')

    def click_element(self, element):
        element.find_element(By.TAG_NAME, 'a').click()

    def scrape_category(self):
        element = WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.ID, 'blog-category')))
        return element.find_element(By.CLASS_NAME, 'cm-con').find_elements(By.CSS_SELECTOR, 'ul > li')

    def load_blog_page(self, url):
        self.driver.get(url)
        self.driver.switch_to.frame('mainFrame')

    def scrape_total_post_cnt(self, element):
        total_post_cnt_txt = element.find_element(By.TAG_NAME, 'span').get_attribute('textContent')
        return total_post_cnt_txt[1:len(total_post_cnt_txt) - 1]

    def scrape_recent_post_date(self):
        if self.is_exist_post_list():
            tbody = self.scrape_post_list().find_element(By.CSS_SELECTOR, 'table > tbody')
            tr = tbody.find_elements(By.TAG_NAME, 'tr')[0]
            return tr.find_element(By.CSS_SELECTOR, 'td.date > div > span').get_attribute('textContent')

        return ''

    def scrape_post_list(self):
        div_post_list = WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.ID, 'toplistWrapper')))

        if self.is_closed_post_list(div_post_list):
            self.open_post_list(self.driver)

        div_post_list = WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.ID, 'toplistWrapper')))
        return div_post_list

    def is_exist_post_list(self):
        try:
            element = WebDriverWait(self.driver, 0.5).until(
                EC.presence_of_element_located((By.CLASS_NAME, 'new_blog_inner2')))
            return False
        except:
            return True

    def is_closed_post_list(self, post_list):
        return post_list.get_attribute('style') == 'display: none;'

    def open_post_list(self, element):
        element.find_element(By.CLASS_NAME, 'btn_openlist').click()
        sleep(0.2)

    def is_category_closed(self):
        element = WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.ID, 'blog-category')))
        return element.find_element(By.CSS_SELECTOR, 'div.cm-body') \
                   .get_attribute('style') == 'display: none;'

    def open_category_list(self):
        self.driver.find_element(By.ID, 'blog-category').find_element(By.CSS_SELECTOR, 'div.cm-head').click()

    def scrape_intro_txt(self):
        element = WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.ID, 'blog-profile')))
        return element.find_element(By.CSS_SELECTOR, 'div.con > p.caption > span') \
            .get_attribute('textContent')

    def scrape_image_url(self):
        try:
            img_url = self.driver.find_element(By.ID, 'blog-profile') \
                .find_element(By.CSS_SELECTOR, 'div.con > p.image > a > img') \
                .get_attribute('src')
        except Exception as e:
            img_url = ""

        return img_url

    def exist_neighbor(self):
        try:
            self.driver.find_element(By.ID, 'blog_buddyconnect')
            return True
        except:
            return False

    def scrape_neighbor_cnt(self):
        self.driver.switch_to.frame('BuddyConnectIframe')
        if self.is_type_1():
            div = self.driver.find_element(By.ID, 'nc_frame1')

        else:
            div = self.driver.find_element(By.ID, 'briefWidget')
            return div.find_element(By.ID, 'followerTotalCount').find_element(By.TAG_NAME, 'strong').get_attribute(
                'textContent')

    def is_type_1(self):
        try:
            self.driver.find_element(By.ID, 'nc_frame1')
            return True
        except:
            return False

    def is_horizontal_line(self, li):
        return li.get_attribute('class').__contains__('dilind')

    def is_depth1_category(self, li):
        return not li.get_attribute('class').__contains__('depth2') and not self.is_horizontal_line(li)

    def scrape_post(self, li):
        posts = []
        li.find_element(By.CSS_SELECTOR, 'div > a').click()
        sleep(0.2)
        if self.is_exist_post_list():
            tbody = self.scrape_post_list().find_element(By.CSS_SELECTOR, 'table > tbody')
            trs = tbody.find_elements(By.TAG_NAME, 'tr')

            for i in range(0, len(trs)):
                tbody = self.scrape_post_list().find_element(By.CSS_SELECTOR, 'table > tbody')
                trs = tbody.find_elements(By.TAG_NAME, 'tr')
                tr = trs[i]

                title = tr.find_element(By.CSS_SELECTOR, 'td.title > div > span > a').get_attribute('textContent')
                date = tr.find_element(By.CSS_SELECTOR, 'td.date > div > span').get_attribute('textContent')
                if len(date) > 10:
                    post_write_date = datetime.strptime(date, '%Y. %m. %d.')
                else:
                    post_write_date = datetime.now()

                if post_write_date <= self.last_post_dt:
                    return posts

                post_url = tr.find_element(By.CSS_SELECTOR, 'td.title > div > span > a').get_attribute('href')
                post_no = self.parse_post_no(post_url)

                page = requests.get(post_url)
                soup = BeautifulSoup(page.text, "html.parser")
                desc = soup.select_one('meta[property="og:description"]')['content']
                img = soup.select_one('meta[property="og:image"]')['content']

                # self.driver.get(tr.find_element(By.CSS_SELECTOR, 'td.title > div > span > a').get_attribute('href'))
                tr.find_element(By.CSS_SELECTOR, 'td.title > div > span > a').click()
                sleep(self.wait_time)

                category = self.scrape_category_on_title()
                if category is None:
                    continue

                url = self.driver.current_url

                posts.append((category, title, desc, img, post_write_date, post_no, url))

            i = 0
            while True:
                pages = self.scrape_post_list().find_element(By.CLASS_NAME, 'blog2_paginate').find_elements(
                    By.TAG_NAME, 'a')
                if i >= len(pages):
                    break
                page = pages[i]
                if page.get_attribute('textContent') == '다음페이지로 이동':
                    i = 0
                page.click()
                sleep(0.2)
                tbody = self.scrape_post_list().find_element(By.CSS_SELECTOR, 'table > tbody')
                trs = tbody.find_elements(By.TAG_NAME, 'tr')
                for j in range(0, len(trs)):
                    tbody = self.scrape_post_list().find_element(By.CSS_SELECTOR, 'table > tbody')
                    trs = tbody.find_elements(By.TAG_NAME, 'tr')
                    tr = trs[j]

                    title = tr.find_element(By.CSS_SELECTOR, 'td.title > div > span > a').get_attribute('textContent')
                    date = tr.find_element(By.CSS_SELECTOR, 'td.date > div > span').get_attribute('textContent')
                    if len(date) > 10:
                        post_write_date = datetime.strptime(date, '%Y. %m. %d.')
                    else:
                        post_write_date = datetime.now()

                    if post_write_date < self.last_post_dt:
                        return posts

                    post_url = tr.find_element(By.CSS_SELECTOR, 'td.title > div > span > a').get_attribute('href')
                    post_no = self.parse_post_no(post_url)

                    page = requests.get(post_url)
                    soup = BeautifulSoup(page.text, "html.parser")
                    desc = soup.select_one('meta[property="og:description"]')['content']
                    img = soup.select_one('meta[property="og:image"]')['content']

                    # self.driver.get(tr.find_element(By.CSS_SELECTOR, 'td.title > div > span > a').get_attribute('href'))
                    tr.find_element(By.CSS_SELECTOR, 'td.title > div > span > a').click()
                    sleep(self.wait_time)

                    category = self.scrape_category_on_title()
                    if category is None:
                        continue

                    url = self.driver.current_url

                    posts.append((category, title, desc, img, post_write_date, post_no, url))
                i += 1

            return posts
        else:
            return []

    def scrape_category_on_title(self):
        category = None
        try:
            category = WebDriverWait(self.driver, 0.5).until(
                EC.presence_of_element_located((By.CLASS_NAME, 'blog2_series'))) \
                .find_element(By.CSS_SELECTOR, 'a').get_attribute('textContent')

            return category
        except:
            try:
                categories = WebDriverWait(self.driver, 0.5).until(
                    EC.presence_of_element_located((By.ID, 'title_1'))) \
                    .find_elements(By.CSS_SELECTOR, 'a')

                category = categories[-1].get_attribute('textContent')
                return category
            except:
                return None

    def parse_post_no(self, url):
        params = url.split('&')
        for param in params:
            key = param.split('=')[0]
            val = param.split('=')[1]
            if key == 'logNo':
                post_seq = val
                return post_seq

    def parse_category_seq(self, url):
        params = url.split('&')
        for param in params:
            key = param.split('=')[0]
            val = param.split('=')[1]
            if key == 'categoryNo':
                category_seq = val
                return category_seq
