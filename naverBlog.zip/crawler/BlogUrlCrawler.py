from datetime import datetime
from time import sleep

from bs4 import BeautifulSoup
from selenium import webdriver

import path
from db_connector.ManhottanDBConn import ManhottanDBConn
from db_connector.PersonConn import PersonConn

class UrlCrawler:

    def __init__(self):
        self.connector = PersonConn()
        self.driver = webdriver.Chrome(path.chrome_driver)

    def close(self):
        self.connector.close()
        self.driver.close()

    def crawl(self, platform_seq, keyword):
        i = 1
        while True:
            url = 'https://section.blog.naver.com/Search/Blog.naver?pageNo=' + str(
                i) + '&orderBy=sim&keyword=' + keyword
            i += 1
            try:
                self.driver.get(url)
                sleep(0.5)
                html = self.driver.page_source
                soup = BeautifulSoup(html, 'html.parser')
                blogs = soup.find_all('a', {'class': 'name_blog'})
                for blog in blogs:
                    url = blog.get('href')
                    blog_name = blog.text[1:len(blog.text) - 1]
                    split_url = url.split('/')
                    blogger = split_url[len(split_url) - 1]
                    data = {'platform_seq': platform_seq, 'url': url, 'blogger': blogger, 'blog_name': blog_name}
                    self.connector.insert_person(data)
                sleep(0.2)

                print('keyword:', keyword, 'pageNo:', i)

                if len(blogs) < 10:
                    break

            except Exception as e:
                data = {'error_type': 'blog url collect', 'url': url, 'error_msg': str(e), 'crt_dt': datetime.now()}
                print('예외:', data)


