from Konlpy import MorphemeAnalyzer


class TagGenerator:

    def __init__(self, phrase1, phrase2, phrase3):
        self.phrase1 = phrase1
        self.phrase2 = phrase2
        self.phrase3 = phrase3

    def gen(self):
        ret = {}

        morpheme_analyzer = MorphemeAnalyzer.instance()
        # level1_pos_list = morpheme_analyzer.pos(self.phrase1)
        # ret['level1_pos_list'] = level1_pos_list
        level1_nouns_list = morpheme_analyzer.nouns(self.phrase1)
        ret['level1_nouns_list'] = level1_nouns_list

        # 3태그까지 생성
        if self.phrase1 != self.phrase2:
            # level2_pos_list = morpheme_analyzer.pos(self.phrase2)
            # ret['level2_pos_list'] = level2_pos_list
            level2_nouns_list = morpheme_analyzer.nouns(self.phrase2)
            ret['level2_nouns_list'] = level2_nouns_list

            # level3_pos_list = morpheme_analyzer.pos(self.phrase3)
            # ret['level3_pos_list'] = level3_pos_list
            level3_nouns_list = morpheme_analyzer.nouns(self.phrase3)
            ret['level3_nouns_list'] = level3_nouns_list
        # 2태그까지 생성
        else:
            # level2_pos_list = morpheme_analyzer.pos(self.phrase3)
            # ret['level2_pos_list'] = level2_pos_list
            level2_nouns_list = morpheme_analyzer.nouns(self.phrase3)
            ret['level2_nouns_list'] = level2_nouns_list

        return ret
