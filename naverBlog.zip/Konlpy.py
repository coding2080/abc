from konlpy.tag import Kkma
from konlpy.tag import Komoran
from konlpy.tag import Hannanum
from konlpy.tag import Twitter
import datetime


# examples = [u"이혼, 상속", u"민사사건 주요 승소사례", u"변호사 직접 상담"]
#
# taggers = [('꼬꼬마', Kkma()),
#            ('코모란', Komoran()),
#            ('트위터', Twitter()),
#            ('한나눔', Hannanum())]
####################################################
# 공통 함수 테스트
####################################################
# for example in examples:
#     start = datetime.datetime.now()
#     for name, tagger in taggers:
#         print('%s %s %s' % ('-' * 10, name, '-' * 10))
#         try:
#             print(tagger.pos(example))  # 품사 태깅
#             print(tagger.morphs(example))  # 형태소만 추출
#             print(tagger.nouns(example))  # 명사 추출
#         except Exception as e:
#             print(e)
#     print(example, ' 형태소 분석 완료 시간 : ', (datetime.datetime.now() - start))
#####################################################
# 단독 함수 및 옵션 테스트
#####################################################
# print('=' * 50)
#
# # [ 꼬꼬마 ]
# print(taggers[0][1].sentences(example))  # 문장 추출
# print('-' * 50)
# # [ 코모란 ]
# print(taggers[1][1].pos(phrase=example, flatten=False))  # flatten=False이면, 어절 단위 PoS Tagging
# print(taggers[1][1].pos(phrase=example, flatten=True))  # 차이 비교용
# print('-' * 50)
# # [ 트위터 ]
# print(taggers[2][1].pos(phrase=example, norm=True, stem=True))  # norm=True 이면, 토큰 노멀라이즈, stem=True 이면, 토큰 스테밍
# print(taggers[2][1].pos(phrase=example, norm=False, stem=False))  # 차이 비교용

class SingletonInstane:
    __instance = None

    @classmethod
    def __getInstance(cls):
        return cls.__instance

    @classmethod
    def instance(cls, *args, **kargs):
        cls.__instance = cls(*args, **kargs)
        cls.instance = cls.__getInstance
        return cls.__instance


class MorphemeAnalyzer(SingletonInstane):
    # examples = ['윤석열 "송영길, 박덕흠·윤미향·이상직 제명 진작에 좀 하지"']

    def __init__(self):
        self.taggers = [('Kkma', Kkma()),
                        ('Komoran', Komoran()),
                        ('Hannanum', Hannanum())]
        # ('트위터', Twitter()),

        self.analyzer = Kkma()

    def pos(self, phrase):
        return self.analyzer.pos(phrase)

    def nouns(self, phrase):
        return self.analyzer.nouns(phrase)

    # def test(self):
    #     for example in self.examples:
    #         start = datetime.datetime.now()
    #         for name, tagger in self.taggers:
    #             print('%s %s %s' % ('-' * 10, name, '-' * 10))
    #             try:
    #                 print(tagger.pos(example))  # 품사 태깅
    #                 print(tagger.morphs(example))  # 형태소만 추출
    #                 print(tagger.nouns(example))  # 명사 추출
    #             except Exception as e:
    #                 print(e)
    #         print(example, ' 형태소 분석 완료 시간 : ', (datetime.datetime.now() - start))
    #
    #         print('=' * 50)
    #
    #         # [ 꼬꼬마 ]
    #         print(self.taggers[0][1].sentences(example))  # 문장 추출
    #         print('-' * 50)
    #         # [ 코모란 ]
    #         print(self.taggers[1][1].pos(phrase=example, flatten=False))  # flatten=False이면, 어절 단위 PoS Tagging
    #         print(self.taggers[1][1].pos(phrase=example, flatten=True))  # 차이 비교용
    #         print('-' * 50)
    #         # [ 한나눔 ]
    #         print(self.taggers[2][1].pos(phrase=example))  # norm=True 이면, 토큰 노멀라이즈, stem=True 이면, 토큰 스테밍
    #         print(self.taggers[2][1].pos(phrase=example))  # 차이 비교용

    # def getNouns(self, phrase):
    #     try:
    #         nouns = self.taggers[0].nouns(phrase)
    #         return nouns
    #     except Exception as e:
    #         print(e)
    #         return []
