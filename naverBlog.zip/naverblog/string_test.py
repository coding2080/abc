import unittest
from datetime import datetime

from db_connector.ManhottanDBConn import ManhottanDBConn
from db_connector.TestConn import TestConn


class MyTestCase(unittest.TestCase):
    def test_something(self):
        # url = 'https://blog.naver.com/PostView.naver?blogId=zzoonies&logNo=221662992651&categoryNo=57&parentCategoryNo=0&viewDate=&currentPage=1&postListTopCurrentPage=1&from=postList'
        # print(self.parse_post_seq(url))

        s = '\n\n\t\t\tabcd agg\t\t\t\t\t'
        print(s.strip())

    def parse_post_seq(self, url):
        params = url.split('&')
        for param in params:
            key = param.split('=')[0]
            val = param.split('=')[1]
            if key == 'logNo':
                post_seq = val
                # print(post_seq)
                break

        return post_seq

    def test_conn(self):
        conn = ManhottanDBConn()
        blog_info = conn.select_info_seq([51, 2, 2])
        if not blog_info:
            print('not exist')
        else:
            print('seq', blog_info[0][0])


if __name__ == '__main__':
    unittest.main()
