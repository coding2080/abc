from datetime import datetime

import pymysql

import db_connection_profile


class PersonConn:

    def __init__(self):
        self.conn = pymysql.connect(host=db_connection_profile.host,
                                    user=db_connection_profile.user,
                                    password=db_connection_profile.password,
                                    db=db_connection_profile.db,
                                    charset='utf8',
                                    connect_timeout=11)
        self.cur = self.conn.cursor(pymysql.cursors.DictCursor)

    def close(self):
        self.cur.close()
        self.conn.close()

    def insert_person(self, data):
        try:
            sql = 'INSERT INTO person(platform_seq, url, id, name) ' \
                  'VALUES (%(platform_seq)s, %(url)s, %(blogger)s, %(blog_name)s)'
            self.cur.execute(sql, data)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def update_person(self, person):
        try:
            sql = 'UPDATE person ' \
                  'SET intro = %(intro)s, profile_url = %(profile_url)s, ' \
                  'recent_post_dt = %(recent_post_dt)s ' \
                  'WHERE person_seq = %(person_seq)s'
            self.cur.execute(sql, person)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def select_people_1000(self, last_seq):
        try:
            print('select_people_1000')
            sql = 'SELECT * ' \
                  'FROM person ' \
                  'WHERE person_seq > %s ' \
                  'LIMIT 1000'
            self.cur.execute(sql, last_seq)
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def select_person_tag(self, data):
        try:
            sql = 'SELECT * ' \
                  'FROM person_tag ' \
                  'WHERE person_seq = %(person_seq)s ' \
                  'AND tag_seq = %(tag_seq)s'
            self.cur.execute(sql, data)
            result = self.cur.fetchall()
            self.conn.commit()
            return result
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def insert_person_tag(self, data):
        try:
            sql = 'INSERT INTO person_tag(person_seq, tag_seq) ' \
                  'VALUES (%(person_seq)s, %(tag_seq)s)'
            self.cur.execute(sql, data)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))

    def update_person_tag(self, data):
        try:
            sql = 'UPDATE person_tag ' \
                  'SET frequency = %(frequency)s ' \
                  'WHERE person_seq = %(person_seq)s and tag_seq = %(tag_seq)s'
            self.cur.execute(sql, data)
            self.conn.commit()
        except pymysql.err.MySQLError as e:
            print('mysql error: ' + str(e))
        except pymysql.err.DataError as e:
            print('database error: ' + str(e))
