import os
import threading
from datetime import datetime
import multiprocessing
import time
from multiprocessing import Process
from time import sleep

from selenium.webdriver.common.by import By

import Konlpy
from Konlpy import MorphemeAnalyzer
from crawler.CategoryCrawler import CategoryCrawler
from crawler.BlogUrlCrawler import UrlCrawler
from db_connector.ManhottanDBConn import ManhottanDBConn
from db_connector.PersonConn import PersonConn
from db_connector.PlatformConn import PlatformConn
from selenium import webdriver
import random
from threading import Thread

from db_connector.KeywrodConn import KeywordConn
from db_connector.TestConn import TestConn
from db_connector.WordConn import WordConn


# 1. url 수집
# 2. 카테고리 및 글 제목 수집
# 3. 형태소 분석

personConn = PersonConn()
platformConnector = PlatformConn()

def crawling_blogger():
    platform = platformConnector.select_platform('blog.naver.com')

    # keywords = ['변호사', '변리사', '회계사', '법무사', '공인중개사']
    keywords = ['여헹']
    for keyword in keywords:
        url_crawler = UrlCrawler()
        url_crawler.crawl(platform[0]['platform_seq'], keyword)
        url_crawler.close()


def crawl_blog_contents():
    category_crawler = CategoryCrawler()
    # last_seq = 5017
    # start_seq = 5017

    people = personConn.select_people_1000(5017)

    for person in people:
        category_crawler.crawl(person)

    # while True:
    #     people = personConn.select_people_1000(last_seq)
    #
    #     for person in people:
    #         category_crawler.crawl(person)

        # if people[-1]['person_seq'] >= 8000:
        #     last_seq = start_seq
        # else:
        #     last_seq += 1000


def test():
    conn = TestConn()
    offset_0 = 0
    while True:
        depth0_list = conn.select_content_seq_1000(0, offset_0)

        for depth0 in depth0_list:
            depth0_seq = depth0[0]
            depth1_list = conn.select_content_by_parent_seq(depth0_seq, offset_0)

            if not depth1_list:
                continue

            depth0_words = conn.select_words(depth0_seq)

            for depth1 in depth1_list:
                depth1_seq = depth1[0]
                depth1_words = conn.select_words(depth1_seq)

                for depth0_word in depth0_words:
                    for depth1_word in depth1_words:
                        score = conn.select_relation(depth0_word[0], depth1_word[0])
                        if not score:
                            conn.insert_relation(depth0_word[0], depth1_word[0], 1)
                        else:
                            old_score = score[0][0]
                            new_score = old_score + 1
                            conn.update_relation_score(depth0_word[0], depth1_word[0], new_score)

            if depth1_list[0][1] == 'category':
                for depth1 in depth1_list:
                    depth1_seq = depth1[0]
                    depth2_list = conn.select_content_by_parent_seq(depth0_seq, offset_0)
                    if not depth2_list:
                        continue

                    depth1_words = conn.select_words(depth1_seq)

                    for depth2 in depth2_list:
                        depth2_seq = depth2[0]
                        depth2_words = conn.select_words(depth2_seq)

                        for depth1_word in depth1_words:
                            for depth2_word in depth2_words:
                                score = conn.select_relation(depth1_word[0], depth2_word[0])
                                if not score:
                                    conn.insert_relation(depth1_word[0], depth2_word[0], 0.5)
                                else:
                                    old_score = score[0][0]
                                    new_score = old_score + 0.5
                                    conn.update_relation_score(depth1_word[0], depth2_word[0], new_score)

        offset_0 += len(depth0_list)
        if len(depth0_list) < 1000:
            break


tagger = MorphemeAnalyzer()


def pos(info):
    print('seq', info[0])
    print('phrase', info[1])
    print('-' * 50)

    blog_info_seq = info[0]
    phrase = info[1]
    print('-' * 50)

    return [blog_info_seq, tagger.analyzer.pos(phrase)]


def nouns(info):
    blog_info_seq = info[0]
    phrase = info[1]
    print('-' * 50)

    return [blog_info_seq, tagger.analyzer.nouns(phrase)]


def tagging():
    try:
        thread_pool = multiprocessing.Pool(3)
        keyword = '구매대행'
        min_date = '2018-12-31'

        conn = WordConn()
        word_master = conn.select_word_all()
        word_dic = dict(map(reversed, word_master))
        compound_master = conn.select_compound_all()
        compound_dic = dict(map(reversed, compound_master))
        # blog_ids = conn.select_top_200_blog_by_keyword(keyword, min_date)
        blog_ids = conn.select_blog_by_keyword(keyword)
        conn.close()
        for blog_id_tuple in blog_ids:
            conn = WordConn()
            blog_id = blog_id_tuple[0]
            print(blog_id)

            # infos = conn.select_blog_info_by_id_and_date(blog_id, min_date)
            infos = conn.select_blog_info_by_id(blog_id)

            # for info in infos:
            #     print(info)

            # 형태소 분석
            pos_results = thread_pool.map(pos, infos)

            # 명사 추출
            nouns_results = thread_pool.map(nouns, infos)

            pos_set = set()

            pos_data_list = []
            nng_data_list = []
            nng_compound_data_list = []
            compound_data_list = []

            for i in range(0, len(pos_results)):
                blog_info_seq = pos_results[i][0]
                pos_list = pos_results[i][1]
                for p in pos_list:
                    # word = conn.select_word(p[0])
                    word = p[0].lower()
                    word_seq = word_dic.get(word)
                    morpheme_code = p[1]
                    pos_set.add(word)
                    if word_seq is None:
                        word_seq = conn.insert_word(word)
                        word_dic[word] = word_seq

                    if word_seq > 0:
                        data_pos = {'blog_info_seq': blog_info_seq, 'word_seq': word_seq,
                                    'morpheme_code': morpheme_code, 'analyzer_code': 'Kkma'}
                        pos_data_list.append(data_pos)

                        if morpheme_code == 'NNG':
                            data_nng = {'blog_info_seq': blog_info_seq, 'word_seq': word_seq,
                                        'analyzer_code': 'Kkma'}
                            nng_data_list.append(data_nng)

                            data_nng_compound = {'blog_info_seq': blog_info_seq, 'ref_seq': word_seq,
                                                 'division': 'NNG', 'analyzer_code': 'Kkma'}
                            nng_compound_data_list.append(data_nng_compound)

                nouns_list = nouns_results[i][1]

                nouns_set = set(nouns_list)
                compound_list = list(nouns_set - pos_set)
                for j in range(0, len(compound_list)):
                    compound_word = compound_list[j].lower()
                    # c_word = conn.select_compound_word(compound_word)
                    compound_seq = compound_dic.get(compound_word)
                    if compound_seq is None:
                        compound_seq = conn.insert_compound_master(compound_word)
                        compound_dic[compound_word] = compound_seq

                    if compound_seq > 0:
                        data_compound = {'blog_info_seq': blog_info_seq, 'compound_master_seq': compound_seq,
                                         'analyzer_code': 'Kkma'}
                        compound_data_list.append(data_compound)

                        data_nng_compound = {'blog_info_seq': blog_info_seq, 'ref_seq': compound_seq,
                                             'division': 'COMPOUND', 'analyzer_code': 'Kkma'}
                        nng_compound_data_list.append(data_nng_compound)

            conn.insert_pos_list(pos_data_list)
            conn.insert_nng_list(nng_data_list)
            conn.insert_nng_compound_list(nng_compound_data_list)
            conn.insert_compound_list(compound_data_list)

            conn.close()
        # last_info = conn.select_last_info_seq()
        # last_seq = last_info[0]
        # if last_info[1] == 0:
        #     last_seq = 0
        #
        # if last_seq is None:
        #     continue
        #
        # infos = conn.select_category_1000(last_seq)
        #
        # # 형태소 분석
        # pos_results = thread_pool.map(pos, infos)
        #
        # # 명사 추출
        # nouns_results = thread_pool.map(nouns, infos)
        #
        # pos_set = set()
        #
        # for i in range(0, len(pos_results)):
        #     blog_info_seq = pos_results[i][0]
        #     pos_list = pos_results[i][1]
        #     for p in pos_list:
        #         word = conn.select_word(p[0])
        #         morpheme_code = p[1]
        #         pos_set.add(p[0])
        #         if not word:
        #             word_seq = conn.insert_word(p[0])
        #         else:
        #             word_seq = word[0][0]
        #
        #         if word_seq > 0:
        #             data_pos = {'blog_info_seq': blog_info_seq, 'word_seq': word_seq,
        #                         'morpheme_code': morpheme_code, 'analyzer_code': 'Kkma'}
        #             conn.insert_pos(data_pos)
        #
        #             if morpheme_code == 'NNG':
        #                 data_nng = {'blog_info_seq': blog_info_seq, 'word_seq': word_seq,
        #                             'analyzer_code': 'Kkma'}
        #                 conn.insert_nng(data_nng)
        #
        #                 data_nng_compound = {'blog_info_seq': blog_info_seq, 'ref_seq': word_seq,
        #                                      'division': 'NNG', 'analyzer_code': 'Kkma'}
        #                 conn.insert_nng_compound(data_nng_compound)
        #
        #     nouns_list = nouns_results[i][1]
        #     # for noun in nouns_list:
        #     #     word = conn.select_nouns(noun)
        #     #     if not word:
        #     #         nouns_seq = conn.insert_nouns_master(noun)
        #     #     else:
        #     #         nouns_seq = word[0][0]
        #     #
        #     #     if nouns_seq > 0:
        #     #         data_pos = {'blog_info_seq': blog_info_seq, 'nouns_master_seq': nouns_seq,
        #     #                     'analyzer_code': 'Kkma'}
        #     #         conn.insert_nouns(data_pos)
        #
        #     nouns_set = set(nouns_list)
        #     compound_list = list(nouns_set - pos_set)
        #     for j in range(0, len(compound_list)):
        #         compound_word = compound_list[j]
        #         c_word = conn.select_compound_word(compound_word)
        #         if not c_word:
        #             compound_seq = conn.insert_compound_master(compound_word)
        #         else:
        #             compound_seq = c_word[0][0]
        #
        #         if compound_seq > 0:
        #             data_compound = {'blog_info_seq': blog_info_seq, 'compound_master_seq': compound_seq,
        #                              'analyzer_code': 'Kkma'}
        #             conn.insert_compound(data_compound)
        #
        #             data_nng_compound = {'blog_info_seq': blog_info_seq, 'ref_seq': compound_seq,
        #                                  'division': 'COMPOUND', 'analyzer_code': 'Kkma'}
        #             conn.insert_nng_compound(data_nng_compound)

        # conn.close()

    except Exception as e:
        print(e)


if __name__ == "__main__":
    # p1 = Process(target=crawl_phrase)
    # p2 = Process(target=tagging)
    # p1.start()
    # p2.start()
    # p1.join()
    # p2.join()

    # 블로그 크롤링
    # crawling_blogger()

    # 카테고리 및 글 제목 크롤링
    crawl_blog_contents()

    # 형태소 분석
    # tagging()

    # 테스트용
    # test()

    # Tagger().test()