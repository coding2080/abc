import os
import threading
from datetime import datetime
import multiprocessing
import time
from multiprocessing import Process
from time import sleep

from selenium.webdriver.common.by import By

import Konlpy
import path
from Konlpy import MorphemeAnalyzer
from crawler.CategoryCrawler import CategoryCrawler
from crawler.BlogUrlCrawler import UrlCrawler
from db_connector.MachineKeywordConn import MachineKeywordConn
from db_connector.ManhottanDBConn import ManhottanDBConn
from db_connector.PersonConn import PersonConn
from db_connector.PlatformConn import PlatformConn
from selenium import webdriver
import random
from threading import Thread

from db_connector.KeywrodConn import KeywordConn
from db_connector.TestConn import TestConn
from db_connector.WordConn import WordConn


# 1. url 수집
# 2. 카테고리 및 글 제목 수집
# 3. 형태소 분석
from tag.analyzer import TagAnalyzer

personConn = PersonConn()
platformConnector = PlatformConn()

def crawling_blogger():
    platform = platformConnector.select_platform('blog.naver.com')
    category_dictionary = [
        {'category_seq': 1, 'category': '국내 여행'}
        , {'category_seq': 2, 'category': '해외 여행'}
        , {'category_seq': 3, 'category': '맛집'}
        , {'category_seq': 4, 'category': '법률'}
        , {'category_seq': 5, 'category': '레슨'}
        , {'category_seq': 6, 'category': '과외'}
        , {'category_seq': 7, 'category': '이사'}
        , {'category_seq': 8, 'category': '중고차 딜러'}
        , {'category_seq': 9, 'category': '보험 설계사'}
        , {'category_seq': 10, 'category': '뷰티'}
        , {'category_seq': 11, 'category': '해외 직구'}
        , {'category_seq': 12, 'category': '인테리어 시공'}
        , {'category_seq': 13, 'category': '운수/운행'}
        , {'category_seq': 14, 'category': '중계사'}
    ]
    # keywords = ['여행', '맛집', '변호사]
    keywords = ['해외 여행', '여행 일본', '여행 해외']
    for keyword in keywords:
        person_category_object = {'category_seq': 2, 'enter_div_cd': 'CRAWLER', 'keyword': keyword}
        url_crawler = UrlCrawler()
        url_crawler.crawl(platform[0]['platform_seq'], keyword, person_category_object)
        url_crawler.close()


def crawl_blog_contents():
    keywords = MachineKeywordConn().select_keywords(path.machine_index)

    category_crawler = CategoryCrawler()
    start_time = time.process_time()

    for keyword in keywords:
        last_seq = 0
        while True:
            people = personConn.select_500_people_by_keyword(keyword[0], last_seq)

            for person in people:
                category_crawler.crawl(person, start_time)

            if people is None or not people or len(people) < 500:
                break
            else:
                last_seq = people[-1]['person_seq']


def test():
    conn = TestConn()
    offset_0 = 0
    while True:
        depth0_list = conn.select_content_seq_1000(0, offset_0)

        for depth0 in depth0_list:
            depth0_seq = depth0[0]
            depth1_list = conn.select_content_by_parent_seq(depth0_seq, offset_0)

            if not depth1_list:
                continue

            depth0_words = conn.select_words(depth0_seq)

            for depth1 in depth1_list:
                depth1_seq = depth1[0]
                depth1_words = conn.select_words(depth1_seq)

                for depth0_word in depth0_words:
                    for depth1_word in depth1_words:
                        score = conn.select_relation(depth0_word[0], depth1_word[0])
                        if not score:
                            conn.insert_relation(depth0_word[0], depth1_word[0], 1)
                        else:
                            old_score = score[0][0]
                            new_score = old_score + 1
                            conn.update_relation_score(depth0_word[0], depth1_word[0], new_score)

            if depth1_list[0][1] == 'category':
                for depth1 in depth1_list:
                    depth1_seq = depth1[0]
                    depth2_list = conn.select_content_by_parent_seq(depth0_seq, offset_0)
                    if not depth2_list:
                        continue

                    depth1_words = conn.select_words(depth1_seq)

                    for depth2 in depth2_list:
                        depth2_seq = depth2[0]
                        depth2_words = conn.select_words(depth2_seq)

                        for depth1_word in depth1_words:
                            for depth2_word in depth2_words:
                                score = conn.select_relation(depth1_word[0], depth2_word[0])
                                if not score:
                                    conn.insert_relation(depth1_word[0], depth2_word[0], 0.5)
                                else:
                                    old_score = score[0][0]
                                    new_score = old_score + 0.5
                                    conn.update_relation_score(depth1_word[0], depth2_word[0], new_score)

        offset_0 += len(depth0_list)
        if len(depth0_list) < 1000:
            break


tagger = MorphemeAnalyzer()


def pos(info):
    print('seq', info[0])
    print('phrase', info[1])
    print('-' * 50)

    blog_info_seq = info[0]
    phrase = info[1]
    print('-' * 50)

    return [blog_info_seq, tagger.analyzer.pos(phrase)]


def nouns(info):
    blog_info_seq = info[0]
    phrase = info[1]
    print('-' * 50)

    return [blog_info_seq, tagger.analyzer.nouns(phrase)]


if __name__ == "__main__":
    # p1 = Process(target=crawl_phrase)
    # p2 = Process(target=tagging)
    # p1.start()
    # p2.start()
    # p1.join()
    # p2.join()

    # 블로그 크롤링
    # crawling_blogger()

    # 카테고리 및 글 제목 크롤링
    # crawl_blog_contents()
    
    # 형태소 분석
    TagAnalyzer().analyze()

    # 테스트용
    # test()

    # Tagger().test()
